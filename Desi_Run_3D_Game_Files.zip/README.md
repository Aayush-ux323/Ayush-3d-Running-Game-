# Desi Run 3D

A mobile-friendly, pseudo-3D endless runner built with plain HTML, CSS and JavaScript. No build tools or external libraries are required.

## Run locally
Open `index.html` in a modern browser.

## Controls
- Left / Right arrow keys or A / D: change lanes
- Up arrow, W or Space: jump
- Down arrow or S: slide
- On mobile: use the buttons or swipe on the game area

## Publish with GitHub Pages
1. Open your public repository `Ayush-3d-Running-Game`.
2. Tap **Add file** → **Upload files**.
3. Upload `index.html` and `README.md` from this folder.
4. Commit the files to the `main` branch.
5. Open **Settings** → **Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Choose branch `main` and folder `/(root)`, then tap **Save**.
8. Wait a few minutes. GitHub Pages will show your website URL on the Pages screen.

Note: this is a lightweight pseudo-3D canvas game, not a full 3D engine game. It uses original drawn shapes and no Subway Surfers assets.
